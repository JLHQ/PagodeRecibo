package com.daa.jpagorecibo.fragmentos;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.daa.jpagorecibo.R;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link FacturaFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class FacturaFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String getSubtotal = "viewValorSubtotal";
    private static final String getTotal = "viewValorTotal";
    private static final String getIVA = "viewValorIVA";
    private static final String getCantidad = "viewValorCantidad";
    private static final String getProducto = "viewValorProducto";
    //SubTotal textView
    TextView subTotalTextView,totalTextView,cantidadTextView, productoTextView,ivaTextView;

    // TODO: Rename and change types of parameters
    private String subTotal ;
    private String total ;
    private String iva ;
    private String cantidad ;
    private String producto ;

    public FacturaFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment FacturaFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static FacturaFragment newInstance(String param1, String param2,String param3,String param4,String param5) {
        FacturaFragment fragment = new FacturaFragment();
        Bundle args = new Bundle();
        args.putString(getSubtotal, param1);
        args.putString(getTotal, param2);
        args.putString(getIVA, param3);
        args.putString(getCantidad, param4);
        args.putString(getProducto, param5);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            subTotal = getArguments().getString(getSubtotal);
            total = getArguments().getString(getTotal);
            iva = getArguments().getString(getIVA);
           cantidad= getArguments().getString(getCantidad);
           producto = getArguments().getString(getProducto);

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.fragment_factura,container,false);
        //Asociar los textViews con las variables
        subTotalTextView=view.findViewById(R.id.viewSubtotal);
        totalTextView=view.findViewById(R.id.viewTotal);
        productoTextView =view.findViewById(R.id.viewProducto);
        cantidadTextView=view.findViewById(R.id.viewCantidad);
        ivaTextView=view.findViewById(R.id.viewIVA);

        subTotalTextView.setText(subTotal);
        totalTextView.setText(total);
        ivaTextView.setText(iva);
        cantidadTextView.setText(cantidad);
        productoTextView.setText(producto);
        // Inflate the layout for this fragment
        return view;
    }
}