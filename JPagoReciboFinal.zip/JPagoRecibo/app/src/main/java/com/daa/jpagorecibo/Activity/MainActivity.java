package com.daa.jpagorecibo.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.daa.jpagorecibo.R;
import com.daa.jpagorecibo.fragmentos.FacturaFragment;
import com.daa.jpagorecibo.fragmentos.PedidosFragment;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {
Button btnPedidos,btnFacturas,btnPagar;
PedidosFragment pedidosFragment;
FacturaFragment facturaFragment;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Inicalizamos variables
        btnFacturas=findViewById(R.id.btnFactura);
        btnPedidos=findViewById(R.id.btnPedidos);
        pedidosFragment=new PedidosFragment();
        facturaFragment= new FacturaFragment();
        fragmentTransaction(pedidosFragment,btnPedidos);


    }

    public void fragmentTransaction(final Fragment fragment, Button btn) {
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Transacción de fragmento
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                //Agregar el fragemnto dentro de un framelayout llamado frame principal
                transaction.replace(R.id.framePrincipal, fragment);
                transaction.commit();
            }
        });

    }
}