package com.daa.jpagorecibo.fragmentos;

import android.os.Bundle;


import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.daa.jpagorecibo.R;

import java.text.DecimalFormat;

/**

 */
public class PedidosFragment extends Fragment {

    EditText edtPrecio,edtCantidad;
    TextView viewValorIva,viewValorSubtotal,viewValorTotal,viewProducto;
    FacturaFragment facturaFragment;
    Button btnPagar;
    Bundle args;
    public PedidosFragment() {
        // Required empty public constructor
    }




    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_pedidios,container,false);
        // Inflate the layout for this fragment
        //Nombre del producto
        viewProducto=view.findViewById(R.id.edtNombre);
        //Fragmento de la factura
        facturaFragment=new FacturaFragment();
        //cantidad que de productos
        edtCantidad=view.findViewById(R.id.edtCantidad);
        //Precio que introduce el usario
        edtPrecio=view.findViewById(R.id.edtPrecio);
        //Botón de pagar
         btnPagar=view.findViewById((R.id.btnPagar));
        //Display del Subtotal
        viewValorSubtotal=view.findViewById(R.id.viewSubtotalValor);
        //Display del Iva
        viewValorIva=view.findViewById(R.id.viewIvaValor);
        //Display del Total
        viewValorTotal=view.findViewById(R.id.viewTotalValor);
        //Bundle para enviar a el otro fragmento
         args=new Bundle();

        //Limpiar los valores
        edtPrecio.setText("");
        edtCantidad.setText("");
        textWatcher(edtPrecio);
        textWatcher(edtCantidad);
        pagar(btnPagar);
        return view;
    }
    String calcularTotal(){
        DecimalFormat df=new DecimalFormat("#.00");
        return  df.format(Double.parseDouble(viewValorSubtotal.getText().toString())+
                Double.parseDouble(viewValorIva.getText().toString()))+"";
    }
    String calcularIva(){
        DecimalFormat df=new DecimalFormat("#.00");
        return df.format(Double.parseDouble(edtPrecio.getText().toString())*0.16*
                Double.parseDouble(edtCantidad.getText().toString()))+"";
    }
    String calcularSubtotal(){
        DecimalFormat df=new DecimalFormat("#.00");
        return df.format(Double.parseDouble(edtPrecio.getText().toString())*Double.parseDouble(edtCantidad.getText().toString()));
    }
    boolean checkEditTextNotEmpty(){

        if(!edtPrecio.getText().toString().isEmpty()&&!edtCantidad.getText().toString().isEmpty()){
            return  true;

        }
        else{
           return false;
        }

    }
    void textWatcher(final EditText edt){
        edt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {

                if (checkEditTextNotEmpty()) {
                    //Se calcula el iva y se manda al TextView
                    viewValorIva.setText(calcularIva());
                    viewValorSubtotal.setText(calcularSubtotal());
                    //Se calcula el total
                    viewValorTotal.setText(calcularTotal());


                }
            }
        });

    }
    void pagar(final Button btn){
    btn.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            if (checkEditTextNotEmpty()) {
                sendParameters();
                //Transacción de fragmento
                FragmentManager fragmentManager = getFragmentManager();
                FragmentTransaction transaction = fragmentManager.beginTransaction();
                //Agregar el fragemnto dentro de un framelayout llamado frame principal
                transaction.replace(R.id.framePrincipal, facturaFragment);
                transaction.commit();
            }
        }
    });
    }
    void sendParameters(){



            args.putString("viewValorTotal", viewValorTotal.getText().toString());
            args.putString("viewValorSubtotal", viewValorSubtotal.getText().toString());
            args.putString("viewValorIVA", viewValorIva.getText().toString());
            args.putString("viewValorCantidad", edtCantidad.getText().toString());
            args.putString("viewValorProducto", viewProducto.getText().toString());
            facturaFragment.setArguments(args);

    }
}